<?php
$config = array(
    'wsdl' => 'http://lfs.tradingcrm.com:8085/mex',
    'apiLocation' => 'https://lfs.tradingcrm.com:8086/CrmServiceBasic',
    'organization' => 'LFS',
    'businessUnitName' => 'Algofund',
    'ownerUserId' => 'c94467c5-5edb-e711-80ce-005056b12a8f',
    'username' => 'lfs',
    'password' => 'Uhdfdu44sfkhGg4',
    'tradingPlatforms' => array(
        'DEMO' => array(
            'name' => 'MTDemo',
            'id' => 'ee613a40-6da3-e711-80ce-005056b12a8f'),
        'REAL' => array(
            'name' => 'MTReal',
            'id' => '07b1570f-6da3-e711-80ce-005056b12a8f',
        ),
    ),
    'wsdlCache' => WSDL_CACHE_MEMORY
);